import java.util.Properties;
    import javax.mail.*;  
    import javax.mail.internet.*;  
      
    public class sendmail {  
     public static void main(String[] args) {  
               
     String to="i4it042@sairamit.edu.in"; 
      
      //Get the session object  
      Properties props = new Properties();  
      props.put("mail.smtp.host", "smtp.gmail.com");  
      props.put("mail.smtp.socketFactory.port", "465");  
      props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
      props.put("mail.smtp.auth", "true");  
      props.put("mail.smtp.port", "465");    
      Session session = Session.getDefaultInstance(props,  
       new javax.mail.Authenticator() {  
       protected PasswordAuthentication getPasswordAuthentication() {  
       return new PasswordAuthentication("xyz.mail@gmail.com","mail@123");//change accordingly  
       }  
      });  
      try {  
       MimeMessage message = new MimeMessage(session);  
       message.setFrom(new InternetAddress("xyz.mail@gmail.com"));//change accordingly  
       message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
       message.setSubject("Pateint Details");     
       message.setText("The patient's Heart beat is abnormal. Immediate attention for the patient is required .It is adviced to contact the patient and their relatives or their emergency contacts to avoid emergency situations. To view the patient's health records click the below link.  http://www.infoziant.com/iot//sairam/");  
       Transport.send(message);  
       System.out.println("message sent successfully");   
      } catch (MessagingException e) {throw new RuntimeException(e);}  
       
     }  
    }  