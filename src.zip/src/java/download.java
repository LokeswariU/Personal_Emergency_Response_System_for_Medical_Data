/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import org.apache.commons.io.FileUtils;

/**
 *
 * 
 */
public class download extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           try{
               
                String id=request.getParameter("id");
                String key1=request.getParameter("key1");
                String key2=request.getParameter("key2");
               
                 Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/multi","root","root");
            Statement st=con.createStatement();
             String sql1="select * from fil where fileid='"+id+"' and userkey='"+key1+"' and adminkey='"+key2+"'";
             ResultSet rs=st.executeQuery(sql1);
             if(rs.next())
             {
                 String name=rs.getString("filename");
              InputStream in = new FileInputStream("D:\\file\\multi\\originalfile\\"+name);
            OutputStream ou = new FileOutputStream("D:\\file\\multi\\download\\"+name);

            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
           
           String sql="update fil set sstat='upload' where fileid='"+id+"'";
           int r1=st.executeUpdate(sql);
           if(r1!=0)
           {  
                while ((len = in.read(buf)) > 0) {
                ou.write(buf, 0, len);
            }
               out.println("<script type=\"text/javascript\">");  
           out.println("alert('File Download');");
           out.println("location='userdownload.jsp'");
           out.println("</script>");
           }
           else
           {
               out.println("<script type=\"text/javascript\">");  
           out.println("alert('Fail Download Failed');");
           out.println("location='userdownload.jsp'");
           out.println("</script>");
           }
             }
             else
              {  
               out.println("<script type=\"text/javascript\">");  
           out.println("alert('Fail Download Failed');");
           out.println("location='userdownload.jsp'");
           out.println("</script>");
           }
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
