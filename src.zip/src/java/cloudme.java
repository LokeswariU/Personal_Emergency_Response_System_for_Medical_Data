/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import Cloudme.CloudmeUser;

/**
 *
 * 
 */
public class cloudme {
     void cloud1(String[] args) throws Exception {        
           String[] s=args;   
           String ss=s[0].toString();
           String path = "D:\\file\\ccaf\\encrypt file\\"+ss;
try{
        CloudmeUser user=new CloudmeUser("multicloud","multicloud123");
         user.getFileManager().uploadFile(path,"/Personaldetails/");
         user.killUser();}catch(Exception e)
         {
             System.out.println(e);
         }
     }
    
}
