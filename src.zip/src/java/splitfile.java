/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * 
 */
public class splitfile {
    public  void split(String s) {
                String FILE_NAME = "D:\\file\\multi\\encrypt file\\"+s;
	 byte PART_SIZE = 5;
		File inputFile = new File(FILE_NAME);
		FileInputStream inputStream;
		String newFileName;
		FileOutputStream filePart;
		int fileSize = (int) inputFile.length();
		int nChunks = 0, read = 0, readLength = PART_SIZE;
		byte[] byteChunkPart;
		try {
			inputStream = new FileInputStream(inputFile);
                        if (fileSize <= 5) {
					readLength = fileSize;
				}
                                else{
                                    readLength=fileSize/3;                                    
                                }
                        int cv=0;
                        String ss=s.replace(".txt", "");
			while (fileSize > 0) {
				cv++;
                                String sss=ss+cv;
				byteChunkPart = new byte[readLength];
				read = inputStream.read(byteChunkPart, 0, readLength);
				fileSize -= read;
				assert (read == byteChunkPart.length);
				nChunks++;
				newFileName = "D:\\file\\multi\\split file\\"+sss+".txt";
				filePart = new FileOutputStream(new File(newFileName));
				filePart.write(byteChunkPart);
				filePart.flush();
				filePart.close();
				byteChunkPart = null;
				filePart = null;
			}
			inputStream.close();
		} catch (IOException exception) {
			exception.printStackTrace();
		}
	}
    
}
